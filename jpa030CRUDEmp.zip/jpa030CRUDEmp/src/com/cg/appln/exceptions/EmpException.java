package com.cg.appln.exceptions;


public class EmpException extends Exception {

	private static final long serialVersionUID = 1L;

	public EmpException() {
		// TODO Auto-generated constructor stub
	}

	public EmpException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmpException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public EmpException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmpException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
