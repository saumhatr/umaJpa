package com.cg.appln.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;


//to define table and entity name
@Entity(name="employee")
@Table(name="EMP")

@NamedQueries({
	@NamedQuery(name="qryEmpsOnSal", query="select e from employee e where SAL between :frm and :to"),
	@NamedQuery(name="qryAllEmpls", query="select e from employee e"),
	@NamedQuery(name="qryEmpWithComm", query="select e from employee e where COMM > 0")
})

@SequenceGenerator(name="seqEmp", sequenceName="EMP_SEQ", allocationSize=1, initialValue=1 )
public class Emp implements Serializable {
	
	private int empNo;
	private String empNm;
	private Float Sal;
	private Float commission;
	private Float totSal;
	
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Emp(int empNo, String empNm, Float sal, Float comm) {
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		Sal = sal;
		this.commission= comm;
	}

	//by default property name is picked up as column name
	//if id is not given then no identifier specified exception:It picks up the property name as 
	//as column name.So, if the property name is same as the column name then no exception.
	//the same goes for id and table
	
	@Id
	@Column(name="EMPNO")
	@GeneratedValue(generator="seqEmp", strategy=GenerationType.SEQUENCE)
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) { //property name:empNo
		this.empNo = empNo;
	}
	
	@Column(name="ENAME")
	public String getEmpNm() { //property name:empNm
		return empNm;
	}
	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}
	
	@Column(name="SAL")
	public Float getsal() {//property name: empSal
		return Sal;
	}
	public void setsal(Float empSal) {
		this.Sal = empSal;
	}
	
	@Column(name="COMM")
	public Float getComm() {
		return commission;
	}

	public void setComm(Float comm) {
		this.commission = comm;
	}
	
	//transient--dont look for a column for this property
	//@Column(name="SAL+COMM")
	@Transient
	public Float getTotSal() {
		return getsal()+(getComm()==null?0:getComm());
	}

/*	public void setTotSal(Float totSal) {
		this.totSal = totSal;
	}*/

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", Sal=" + Sal
				+ ", commission=" + commission + ", totSal=" + getTotSal() + "]";
	}
	
	
	
	/*public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Emp(int empNo, String empNm, Float empSal) {
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		this.empSal = empSal;
	}*/
	
	
	
}
