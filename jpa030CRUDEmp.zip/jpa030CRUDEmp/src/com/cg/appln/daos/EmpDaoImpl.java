package com.cg.appln.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import com.cg.appln.entities.Emp;
import com.cg.appln.exceptions.EmpException;
import com.cg.appln.util.EntityManagerUtil;

public class EmpDaoImpl implements IEmpDao {

	private EntityManagerUtil util;
	private EntityManager mgr;
	
	public EmpDaoImpl() throws EmpException {
		util = new EntityManagerUtil();
		mgr=util.getManager();
	}

	/*@Override
	protected void finalize() throws Throwable {
		//util.close();
		super.finalize();
	}*/

	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		Emp emp=mgr.find(Emp.class, empNo);
		//System.out.println(emp);
		if(emp==null){
			throw new EmpException("Invalid Employee Id");
		}
		return emp;
	}
	
	/*@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpException {
		Emp emp=mgr.find(Emp.class, empNo);
		//System.out.println(emp);
		if(emp==null){
			throw new EmpException("Invalid Employee Id");
		}
		mgr.detach(emp);
		return emp;
	}*/
	

	@Override
	public List<Emp> getEmpList() throws EmpException {
		try {
			//employee entity name
			TypedQuery<Emp> qry= mgr.createNamedQuery("qryAllEmpls", Emp.class);
			List<Emp> empList= qry.getResultList();
						
			return empList;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Emproper query formation",e);
		}
	}

	@Override
	public Emp insertEmp(Emp emp) throws EmpException {
		//at this point emp is a transient object
		try {
			mgr.getTransaction().begin();
			mgr.persist(emp); //persist method makes it persistent(stores in entity mgr)
			mgr.getTransaction().commit();
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Violeted column size or name constraint",e);
		}
		
		return emp;
	}

	@Override
	public boolean updateName(int empNo, String newName) throws EmpException {
		try {
			mgr.getTransaction().begin();
			Emp emp= this.getEmpDetails(empNo);
			emp.setEmpNm(newName);
			mgr.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			throw new EmpException("Name updation failed",e);
		}
	}

	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
		try {
			mgr.getTransaction().begin();
			System.out.println("------------");
			mgr.merge(emp);
			mgr.getTransaction().commit();
			return true;
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			throw new EmpException("employee updation failed",e);
		}
		
	}

	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		try {
			mgr.getTransaction().begin();
			Emp emp= this.getEmpDetails(empNo);
			mgr.remove(emp);// this removes row from table but entity mgr still has this object as a transient object.
			System.out.println("*************");
			System.out.println(emp);//op comes coz its present in entity mgr
			mgr.getTransaction().commit();
			System.out.println(emp);//op comes coz its present in entity mgr
		} catch (RollbackException  | EmpException e1) {
			// TODO Auto-generated catch block
			throw new EmpException("Not deleted!", e1);
		}
		return false;
	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpException {
		//String qryStr="select e from employee e where SAL between :frm and :to";
		
		TypedQuery<Emp>  qry=mgr.createNamedQuery("qryEmpsOnSal", Emp.class);
		qry.setParameter("frm", from);
		qry.setParameter("to", to);
		
		
		return qry.getResultList();
	}

	@Override
	public List<Emp> getEmpsForCommision() throws EmpException {
		
		TypedQuery<Emp> qry= mgr.createNamedQuery("qryEmpWithComm", Emp.class);
	
		List<Emp> empList= qry.getResultList();	
		return empList;

	}
	
	
	
}
