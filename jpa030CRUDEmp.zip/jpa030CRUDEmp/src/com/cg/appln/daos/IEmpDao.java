package com.cg.appln.daos;

import java.util.List;

import com.cg.appln.entities.Emp;
import com.cg.appln.exceptions.EmpException;

	public interface IEmpDao {
		
		Emp getEmpDetails(int empNo) throws EmpException;
		//Emp getEmpDetailsSafe(int empNo) throws EmpException;
		List<Emp> getEmpList() throws EmpException;
		Emp insertEmp(Emp emp)throws EmpException;
		boolean updateName(int empNo, String empName)throws EmpException;
		boolean updateEmp(Emp emp)throws EmpException;
		boolean deleteEmp(int empNo)throws EmpException;
		List<Emp> getEmpOnSal(float from, float to)throws EmpException;
		List<Emp> getEmpsForCommision()throws EmpException;
	}
	