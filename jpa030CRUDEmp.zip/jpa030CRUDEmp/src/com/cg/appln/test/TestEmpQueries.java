package com.cg.appln.test;

import java.util.List;

import com.cg.appln.entities.Emp;
import com.cg.appln.exceptions.EmpException;
import com.cg.appln.services.EmpServiceImpl;
import com.cg.appln.services.IEmpServices;

public class TestEmpQueries {

	public static void main(String[] args) {
		try {
			IEmpServices sevices=new EmpServiceImpl();
			
			/*List<Emp> empList=sevices.getEmpOnSal(100, 10000);
			System.out.println(empList);*/
			
			/*Emp emp=new Emp();
			emp.setEmpNm("bbb");
			emp.setsal(450.0f);
			System.out.println(sevices.insertEmp(emp));*/
			List<Emp> empList= sevices.getEmpList();
			System.out.println(empList);
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
