package com.cg.appln.test;

import com.cg.appln.entities.Emp;
import com.cg.appln.exceptions.EmpException;
import com.cg.appln.services.EmpServiceImpl;
import com.cg.appln.services.IEmpServices;

public class TestEmpService {

	
	public static void main(String args[]){
		
		IEmpServices services;
		
		try {
			services = new EmpServiceImpl();
			/*System.out.println("*****************Employee with id=7369********************");
			System.out.println(services.getEmpDetails(7369)+"\n");
			
			System.out.println("*****************Inserted this employee********************\n");
			Emp emp= new Emp(11, "Sia", 5000.0f);
			services.insertEmp(emp);
			System.out.println(services.getEmpDetails(11)+"\n");
			
			System.out.println("*****************Updated name of employee with id=11 ********************\n");
			System.out.println(services.updateName(11, "Tia"));
			System.out.println(services.getEmpDetails(11)+"\n");
			
			System.out.println("*****************List Of Employees********************");
			for(Emp e:services.getEmpList()){
				System.out.println(e);
			}*/
			
			
			//transient.As, Entity manager cant see the setter methods.And it becomes persistence
			//wher persist, merge or find method is applied
			/*Emp emp= new Emp();
			emp.setEmpNm("Karan");
			emp.setEmpNo(5555);
			emp.setsal(2000.0f);
			services.updateEmp(emp);*/
			//services.deleteEmp(11);
			

			
		} catch (EmpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
