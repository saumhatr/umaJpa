package com.cg.appln.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.cg.appln.exceptions.EmpException;

public class EntityManagerUtil {

	private EntityManagerFactory factory;
	
	public EntityManagerUtil() throws EmpException {
		try {
			factory=Persistence.createEntityManagerFactory("JPA-PU");
		} catch (PersistenceException e) {
			throw new EmpException("Persistence creation failed!",e);
		}		
	}
	public EntityManager getManager(){
		
		return factory.createEntityManager();
	}
	
	@Override
	protected void finalize() throws Throwable {
		if(factory!=null){
			factory.close();
		}
		super.finalize();
	}
	
}
