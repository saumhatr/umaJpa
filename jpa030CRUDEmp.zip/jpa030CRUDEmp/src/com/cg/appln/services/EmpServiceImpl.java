package com.cg.appln.services;


import java.util.List;

import com.cg.appln.daos.EmpDaoImpl;
import com.cg.appln.daos.IEmpDao;
import com.cg.appln.entities.Emp;
import com.cg.appln.exceptions.EmpException;

public class EmpServiceImpl implements IEmpServices {

	private IEmpDao dao;
	public EmpServiceImpl() throws EmpException {
		dao=new EmpDaoImpl();
	}

	/*@Override
	public Emp getEmpDetailsSafe(int empNo) throws EmpException {
		
		return dao.getEmpDetailsSafe(empNo);
	}*/
	@Override
	public Emp getEmpDetails(int empNo) throws EmpException {
		
		return dao.getEmpDetails(empNo);
	}
	@Override
	public List<Emp> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}

	@Override
	public Emp insertEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.insertEmp(emp);
	}

	@Override
	public boolean updateName(int empNo, String empName) throws EmpException {
		// TODO Auto-generated method stub
		return dao.updateName(empNo, empName);
	}

	@Override
	public boolean updateEmp(Emp emp) throws EmpException {
	
		return dao.updateEmp(emp);
	}

	@Override
	public boolean deleteEmp(int empNo) throws EmpException {
		// TODO Auto-generated method stub
		return dao.deleteEmp(empNo);
	}

	@Override
	public List<Emp> getEmpOnSal(float from, float to) throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpOnSal(from, to);
	}

	@Override
	public List<Emp> getEmpsForCommision() throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpsForCommision();
	}

}
